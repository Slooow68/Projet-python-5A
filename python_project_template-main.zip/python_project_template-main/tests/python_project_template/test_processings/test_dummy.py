"""Testing dummy file."""

from python_project_template.processings.dummy import dummy

def test_dummy()->None:
    """Dummy test"""
    assert dummy() == 'dummy'
