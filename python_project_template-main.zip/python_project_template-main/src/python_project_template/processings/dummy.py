"""Dummy file for dummy template."""

def dummy()->str:
    """Return dummy.

    Returns:
        str: dummy
    """
    return 'dummy'